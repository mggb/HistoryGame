<?php wp_footer(); ?>
<div id="footer-wrapper">
    <section id="footer" class="container">
        <div class="row">
            <div class="8u 12u(mobile)">
                <section>
                    <header>
                        <h2>Blandit nisl adipiscing</h2>
                    </header>
                    <ul class="dates">
                        <?php $my_query = new WP_Query('category_name=events&showposts=5'); ?>
                        <?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
                            <li>
                                <span class="date"><?php the_field('event_date') ?></span>
                                <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                                <p><?php the_excerpt() ?></p>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </section>
            </div>
            <div class="4u 12u(mobile)">
                <section>
                    <header>
                        <h2>What's this all about?</h2>
                    </header>
                    <a href="#" class="image featured"><img src="images/pic10.jpg" alt="" /></a>
                    <p>
                        This is <strong>Dopetrope</strong> a free, fully responsive HTML5 site template by
                        <a href="http://twitter.com/ajlkn">AJ</a> for <a href="http://html5up.net/">HTML5 UP</a> It's released for free under
                        the <a href="http://html5up.net/license/">Creative Commons Attribution</a> license so feel free to use it for any personal or commercial project &ndash; just don't forget to credit us!
                    </p>
                    <footer>
                        <a href="#" class="button">Find out more</a>
                    </footer>
                </section>
            </div>
        </div>
        <div class="row">
            <div class="12u">

                <!-- Copyright -->
                <div id="copyright">
                    <ul class="links">
                        <li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </section>
</div>
</div>
</body>

</html>
<?php
get_header(); ?>
			<!-- Main -->
				<div id="main-wrapper">
					<div class="container">
						<div class="row">
							<div class="12u">

								<!-- Blog -->
									<section>
										<header class="major">
											<h2>The Blog</h2>
										</header>
										<div class="row">
                                            <?php
                                            $args= array(
                                                'post_type' => 'post',
                                                'posts_per_page' => 2,
                                                'order' =>'DESC'
                                            );
                                            ?>
                                            <?php
                                            $query_articles = new WP_Query($args);
                                            if($query_articles->have_posts() ) :
                                            while($query_articles->have_posts() ) : $query_articles->the_post();?>
											<div class="6u 12u(mobile)">
												<section class="box">
													<a href="#" class="image featured"><img src="images/pic08.jpg" alt="" /></a>
													<header>
														<h3><?php the_title();?></h3>
														<p>Posted 45 minutes ago</p>
													</header>
                                                    <p><?php the_excerpt() ?></p>
													<p><?php the_excerpt() ?></p>
													<footer>
														<ul class="actions">
                                                            <li><a href="<?php the_permalink() ?>" class="button icon fa-file-text">Continue Reading</a></li>
                                                            <li><a href="#" class="button alt icon fa-comment">33 comments</a></li>
														</ul>
													</footer>
												</section>
											</div>
                                                <?php
                                            endwhile;
                                            endif;
                                            wp_reset_postdata();
                                            ?>
										</div>
									</section>
							</div>
						</div>
					</div>
				</div>
<?php get_footer(); ?>

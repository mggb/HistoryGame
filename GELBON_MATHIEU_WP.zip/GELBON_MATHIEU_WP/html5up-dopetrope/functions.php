<?php
add_theme_support('post-thumbnails');
add_image_size('466x466', 466, 466, true);
add_action('wp_enqueue_scripts', 'td_wp_enqueue_scripts');

/*add_action  permet de fixer sur un fonction wordpress
permet d'ajouter/supprimer nos element à nous dans wordpress (feuille de style et js)
dès qu'on appelle la fonction wordpress 'wp_enqueue_scripts',qui une fois appelée, wordpress appelera notre fonction
get_stylesheet_directory_uri() renvoie l'adresse du theme
--------------
wp_register_style($id, $le_chemin,array(), ver:false, media:'all')
/* configurer la feuile de style,
** array() correspond à un dépendance(l'élément va se charger avant) est-ce qu'un element doit tre chargé avant le mien
** ver:false, amettre en false sinon la version sera afficher sur l'ulr (en get)

wp_enqueue_style($id) permet d'ajouter dans wordpress
/* SCRIPT -----------------------
 wp_register_script($id, $path_file, array(), version(true ou false), footer(true ou false));
L'un ne va pas sans l'autre
*/
/* ajouter des image fonction*/


function td_wp_enqueue_scripts() {
    $path =get_stylesheet_directory_uri();

    $css =array(
        'ie8' => $path . '/assets/css/ie8.css',
        'main' => $path . '/assets/css/main.css',
        'font' => $path . '/assets/css/font-awesome.min.css'
    );
    //script css
    foreach ($css as $id => $path_file) {
        wp_register_style($id, $path_file, array(), false, 'all');
        wp_enqueue_style($id);
    }

    /**
     * AJOUT des JS
     */
    $js=array(
        //'jquery' => 'https://code.jquery.com/jquery-3.3.1.min.js'
        'jquery' => $path . '/assets/js/jquery.min.js',
        'util' => $path . '/assets/js/util.js',
        'main' => $path . '/assets/js/main.js',
    );
    //supp la version de base de wp
    wp_deregister_script('jquery');

    foreach ($js as $id => $path_file) {
        wp_register_script($id, $path_file, array(), false, true);
        wp_enqueue_script($id);
    }
}

<?php
get_header(); ?>
			<!-- Main -->
				<div id="main-wrapper">
					<div class="container">
						<div class="row">
							<div class="8u 12u(mobile)">
                                <?php
                                $args= array(
                                    'post_type' => 'post',
                                    'posts_per_page' => 6,
                                    'order' =>'DESC'
                                );
                                ?>
                                <?php
                                $query_articles = new WP_Query($args);
                                if($query_articles->have_posts() ) :
                                while($query_articles->have_posts() ) : $query_articles->the_post();?>
								<!-- Content -->
									<article class="box post">

										<header>
											<h2><?php the_title()?></h2>
											<p><?php the_content() ?></p>
										</header>
										<p>
                                            <?php the_content() ?>
										</p>
										<p>
                                            <?php the_content() ?>
										</p>
									</article>
                                    <?php
                                endwhile;
                                endif;
                                wp_reset_postdata();
                                ?>


                            </div>
							<div class="4u 12u(mobile)">
                                <?php
                                $args= array(
                                    'post_type' => 'post',
                                    'posts_per_page' => 6,
                                    'order' =>'DESC'
                                );
                                ?>
                                <?php
                                $query_articles = new WP_Query($args);
                                if($query_articles->have_posts() ) :
                                while($query_articles->have_posts() ) : $query_articles->the_post();?>
								<!-- Sidebar -->
									<section class="box">
										<a href="#" class="image featured"><img src="images/pic09.jpg" alt="" /></a>
										<header>
											<h3>Sed etiam lorem nulla</h3>
										</header>
										<p>Lorem ipsum dolor sit amet sit veroeros sed amet blandit consequat veroeros lorem blandit  adipiscing et feugiat phasellus tempus dolore ipsum lorem dolore.</p>
										<footer>
											<a href="#" class="button alt">Magna sed taciti</a>
										</footer>
									</section>
                                    <?php
                                endwhile;
                                endif;
                                wp_reset_postdata();
                                ?>
							</div>
						</div>
					</div>
				</div>
			<?php get_footer()?>

<?php
get_header(); ?>
			<!-- Main -->
				<div id="main-wrapper">
					<div class="container">

						<!-- Content -->
							<article class="box post">
								<a href="#" class="image featured"><img src="images/pic01.jpg" alt="" /></a>
								<header>
									<h2><?php the_title()?></h2>
									<p><?php the_content() ?></p>
								</header>
								<p>
                                    <?php the_content() ?>
								</p>
								<p>
                                    <?php the_content() ?>
								</p>
							</article>

					</div>
				</div>
            <?php get_footer(); ?>
